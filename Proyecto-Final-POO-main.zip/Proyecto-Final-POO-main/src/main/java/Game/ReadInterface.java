package Game;

//Byron Huaraca
//Jorge Alaba
//Bernabé Dávila 

import javafx.collections.ObservableList;

public interface ReadInterface {

    public ObservableList readTwo();

    public ObservableList read();

}
